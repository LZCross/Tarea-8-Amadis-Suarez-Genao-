import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as L from 'leaflet';

/*
 * =====================================================================
 * Tarea: App Ionic - Formulario + Mapa con marcador
 * Autor: [Nombre del estudiante]
 * Matrícula: [Matrícula del estudiante]
 * =====================================================================
 * Pantalla 2 (MapaPage):
 * Recibe nombre, apellido, latitud y longitud por queryParams desde
 * HomePage. Dibuja un mapa (Leaflet + OpenStreetMap) con un marcador
 * en esas coordenadas. Al hacer clic en el marcador se abre un popup
 * con el nombre, el apellido y la ciudad/país obtenidos mediante
 * geocodificación inversa (API Nominatim de OpenStreetMap).
 * =====================================================================
 */
@Component({
  selector: 'app-mapa',
  templateUrl: 'mapa.page.html',
  styleUrls: ['mapa.page.scss']
})
export class MapaPage implements OnDestroy {
  private mapa: L.Map | undefined;

  // Datos recibidos desde la pantalla anterior
  nombre = '';
  apellido = '';
  lat = 0;
  lng = 0;

  // Ciudad/país resuelto por geocodificación inversa, cacheado para no
  // volver a llamar a la API cada vez que se hace clic en el marcador
  ciudadPais = 'Buscando ubicación...';

  constructor(private route: ActivatedRoute) {
    // Leemos los parámetros que envió HomePage al navegar
    this.route.queryParams.subscribe((params) => {
      this.nombre = params['nombre'] ?? '';
      this.apellido = params['apellido'] ?? '';
      this.lat = Number(params['lat']);
      this.lng = Number(params['lng']);
    });
  }

  // ionViewDidEnter se ejecuta cuando la vista ya está en el DOM,
  // momento correcto para inicializar Leaflet (necesita el <div> creado)
  ionViewDidEnter() {
    this.iniciarMapa();
    this.obtenerCiudadPais();
  }

  // Crea el mapa de Leaflet centrado en las coordenadas y coloca el marcador
  private iniciarMapa() {
    this.mapa = L.map('mapaContenedor').setView([this.lat, this.lng], 13);

    // Capa base de mosaicos de OpenStreetMap (gratuita, sin API key)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(this.mapa);

    const marcador = L.marker([this.lat, this.lng]).addTo(this.mapa);

    // Al hacer clic en el marcador se abre el popup con nombre,
    // apellido y ciudad/país (este último ya resuelto o "cargando")
    marcador.on('click', () => {
      marcador
        .bindPopup(
          `<b>${this.nombre} ${this.apellido}</b><br>${this.ciudadPais}`
        )
        .openPopup();
    });
  }

  // Geocodificación inversa: convierte lat/lng en ciudad y país usando
  // la API pública Nominatim de OpenStreetMap (no requiere API key)
  private obtenerCiudadPais() {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${this.lat}&lon=${this.lng}`;

    fetch(url)
      .then((respuesta) => respuesta.json())
      .then((datos) => {
        const direccion = datos.address ?? {};
        const ciudad =
          direccion.city || direccion.town || direccion.village || direccion.county || 'Ciudad desconocida';
        const pais = direccion.country || 'País desconocido';
        this.ciudadPais = `${ciudad}, ${pais}`;
      })
      .catch(() => {
        this.ciudadPais = 'No se pudo obtener la ubicación';
      });
  }

  ngOnDestroy() {
    // Liberamos el mapa al salir de la pantalla para evitar fugas de memoria
    if (this.mapa) {
      this.mapa.remove();
    }
  }
}
