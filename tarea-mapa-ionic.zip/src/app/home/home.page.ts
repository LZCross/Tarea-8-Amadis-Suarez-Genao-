import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

/*
 * =====================================================================
 * Tarea: App Ionic - Formulario + Mapa con marcador
 * Autor: [Nombre del estudiante]
 * Matrícula: [Matrícula del estudiante]
 * =====================================================================
 * Pantalla 1 (HomePage):
 * Captura nombre, apellido, latitud y longitud del usuario.
 * Al presionar "Siguiente" valida los campos y navega hacia la
 * pantalla del mapa (MapaPage), enviando los datos por queryParams.
 * =====================================================================
 */
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class HomePage {
  // Modelo de datos que llena el usuario en el formulario
  nombre: string = '';
  apellido: string = '';
  latitud: number | null = null;
  longitud: number | null = null;

  constructor(private router: Router, private alertController: AlertController) {}

  // Se ejecuta al presionar el botón "Siguiente"
  async irAlMapa() {
    // Validación simple de los campos antes de navegar
    if (
      !this.nombre.trim() ||
      !this.apellido.trim() ||
      this.latitud === null ||
      this.longitud === null
    ) {
      const alerta = await this.alertController.create({
        header: 'Datos incompletos',
        message: 'Por favor llena nombre, apellido, latitud y longitud.',
        buttons: ['OK']
      });
      await alerta.present();
      return;
    }

    // Validación de rangos válidos de coordenadas geográficas
    if (this.latitud < -90 || this.latitud > 90 || this.longitud < -180 || this.longitud > 180) {
      const alerta = await this.alertController.create({
        header: 'Coordenadas inválidas',
        message: 'Latitud debe estar entre -90 y 90, longitud entre -180 y 180.',
        buttons: ['OK']
      });
      await alerta.present();
      return;
    }

    // Navegamos a la pantalla del mapa enviando los datos capturados
    this.router.navigate(['/mapa'], {
      queryParams: {
        nombre: this.nombre,
        apellido: this.apellido,
        lat: this.latitud,
        lng: this.longitud
      }
    });
  }
}
