import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

// -----------------------------------------------------------------------
// Rutas de la aplicación.
// 'home' es la Pantalla 1 (formulario: nombre, apellido, latitud, longitud)
// 'mapa' es la Pantalla 2 (mapa con marcador y popup con los datos)
// -----------------------------------------------------------------------
const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then((m) => m.HomePageModule)
  },
  {
    path: 'mapa',
    loadChildren: () => import('./mapa/mapa.module').then((m) => m.MapaPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
