import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.escuela.tareamapaionic',
  appName: 'tarea-mapa-ionic',
  webDir: 'www'
};

export default config;
