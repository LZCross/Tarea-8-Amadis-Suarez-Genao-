# Tarea Mapa Ionic

App Ionic (Angular) con 3 pantallas:

1. **Formulario** (`src/app/home`): captura nombre, apellido, latitud y longitud.
2. **Mapa** (`src/app/mapa`): al presionar "Siguiente" se muestra un mapa (Leaflet + OpenStreetMap) con un marcador en las coordenadas indicadas.
3. **Popup del marcador**: al hacer clic en el marcador aparece el nombre, apellido y la ciudad/país de esa ubicación (obtenidos por geocodificación inversa con la API pública de Nominatim/OpenStreetMap, sin necesidad de API key).

## Cómo abrir en Visual Studio Code

1. Descomprime este .zip.
2. Abre la carpeta `tarea-mapa-ionic` en VS Code.
3. Abre una terminal en VS Code (`Ctrl + ñ` o `Terminal > New Terminal`).
4. Instala las dependencias:
   ```
   npm install
   ```
5. Corre la app en el navegador:
   ```
   ionic serve
   ```
   (si no tienes Ionic CLI instalado globalmente, primero ejecuta `npm install -g @ionic/cli`, o usa `npx ionic serve`)

## Notas

- No requiere ninguna API key: el mapa usa mosaicos de OpenStreetMap y la geocodificación inversa usa Nominatim (ambos gratuitos).
- El código está comentado en `src/app/home/home.page.ts` y en `src/app/mapa/mapa.page.ts`, indicando qué hace cada parte.
- Antes de entregar/grabar el video, reemplaza `[Nombre del estudiante]` y `[Matrícula del estudiante]` en esos dos archivos por tus datos reales.
